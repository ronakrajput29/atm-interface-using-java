# Octanet_Intern_Atm_interface_task1

# ATM INTERFACE
# The ATMs in our cities are built on Python, as we have all seen them. It is a console-based application with five different classes. In order to use the system, the user must enter his or her user ID and pin when it starts. Once the details are entered successfully, ATM functionality is unlocked. As a result of the project, the following operations can be performed:

# Transactions History
# Withdraw
# Deposit
# Transfer
# Quit
